# xor [100 pts]

**Category:** REV
**Solves:** 1

## Description
>

**Hint**
* -

## Solution

### Flag

