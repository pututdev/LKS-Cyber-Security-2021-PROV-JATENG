# Wangy [100 pts]

**Category:** WEB
**Solves:** 1

## Description
>http://202.162.35.59:10002/
wangy wangy wangy
<img src="https://cdn.discordapp.com/attachments/710631743018762291/821246447047147520/158661456_443626276959827_2425025041534178637_n.png" width="100px">

**Hint**
* remote code execution

## Solution

### Flag

