# Login [100 pts]

**Category:** WEB
**Solves:** 3

## Description
>simple strcmp
http://202.162.35.59:10001

**difficulty: *sangad ez***<br>
Sekilas ingfo: ini cuma soal pemanasan untuk testing platform, soal asli belum tentu memiliki tingkat kesulitan yang sama.

**Hint**
* string compare <br>
https://www.php.net/manual/en/function.strcmp.php

## Solution

### Flag

