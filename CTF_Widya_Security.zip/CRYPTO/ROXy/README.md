# ROXy [100 pts]

**Category:** CRYPTO
**Solves:** 0

## Description
>Simple one byte key encryption

**Hint**
* X O R

## Solution

### Flag

