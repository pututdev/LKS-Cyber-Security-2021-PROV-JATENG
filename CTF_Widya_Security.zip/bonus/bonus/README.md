# bonus [100 pts]

**Category:** bonus
**Solves:** 14

## Description
>balikan kata ini.. 

{oya}1202SKL

**Hint**
* -

## Solution

### Flag

