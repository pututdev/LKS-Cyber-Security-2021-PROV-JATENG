# File Carving [100 pts]

**Category:** FORENSIC
**Solves:** 9

## Description
>Last night, I hid a secret file inside of an image

Format flag: LKS2021{}

**Hint**
* -

## Solution

### Flag

