# buffow [100 pts]

**Category:** PWN
**Solves:** 2

## Description
>nc 202.162.35.59 30001

**Hint**
* -

## Solution

### Flag

